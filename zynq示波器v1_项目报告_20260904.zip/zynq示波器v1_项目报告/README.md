# Zynq 示波器 V1 项目报告

本目录是 AC880 + ACM108 + Zynq-7020 + PetaLinux + Qt 示波器工程的交接、复现和后续开发入口。

## 阅读顺序

1. docs/analysis/00_project_inventory.md：工程清单与文件边界。
2. docs/analysis/09_system_dataflow.md：ADC 到 PL、DMA、DDR、Linux、Qt、LCD 的端到端数据流。
3. docs/zynq简易示波器项目v1.md：完整技术报告和分阶段计划。
4. docs/analysis/07_known_issues.md、08_unknowns.md：已知问题和待确认项。

## 分阶段计划

| 阶段 | 目标 | 退出门禁 |
|---|---|---|
| 0 资料基线 | 固定器件、管脚、版本、DDR 归属 | 资料、工程入口、启动介质明确 |
| 1 Vivado | PS/PL、采集、DMA、LCD、触摸、XSA | Validate、综合、实现、DRC/时序通过，XSA 含最新 bitstream |
| 2 PetaLinux | 导入 XSA，生成 Linux、DTB、rootfs、BOOT.BIN | device-tree、完整构建、打包和反编译通过 |
| 3 Linux 控制 | 验证 AXI-Lite、UIO、状态寄存器 | /dev/uio0 可重复控制和读取 |
| 4 Linux DMA | 验证 S2MM、PS DDR 环形缓冲、段序号 | 内部测试源和外部信号无溢出/丢段 |
| 5 显示触摸 | DRM/KMS、fbdev、GT911、字体 | card0、event0、IRQ、中文显示正常 |
| 6 Qt 示波器 | 采集线程、环形缓存、FFT、测量、交互 | 连续运行、波形/频谱可切换 |
| 7 板级验收 | 1 kHz/1 Vpp、标定、长时间运行 | 幅值/频率误差、抖动、丢段达标 |
| 8 V1 冻结 | 哈希、日志、产物、复现文档 | 新成员可从零构建并上板 |

## 修改边界

报告生成没有修改 Vivado、PetaLinux 或 Qt 功能代码。后续 Vivado 操作使用 Vivado GUI/Tcl；PetaLinux 持久化修改只放 project-spec/meta-user；Qt 修改源文件后重新交叉编译。不要直接编辑 .xpr、.xci 或自动生成 DTS。

